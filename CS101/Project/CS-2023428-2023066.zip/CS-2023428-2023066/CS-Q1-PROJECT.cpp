//Q1 CS PROJECT BY:
//HARIS(2023428) AND AHMAD IBRAHIM(2023066)
#include <stdlib.h>
#include <sys/time.h>
#include <iostream>
#include <string>
using namespace std;

// function prototypes
int senseDistance();  
void getSensors(int sensors[]);
void printSensors(int sensors[], string labels[]);
int furthest(int sensors[]);

// main function
int main() {
    int sensors[4]; // array of four distance sensors
    string labels[4]; // array of labels for each sensor
    int dir;          // indicates which direction to go next
    srand(time(NULL)); // initialize the random number generator
    labels[0] = "north"; // initialize the sensor labels
    labels[1] = "west";
    labels[2] = "south";
    labels[3] = "east";

    for (int i = 0; i < 5; i++) { // simulate 5 moves by the robot
        getSensors(sensors);      // get values for all the sensors
        printSensors(sensors, labels); // print out the sensor values
        dir = furthest(sensors);   // find the direction that is furthest from an obstacle
        cout << "moving " << labels[dir] << endl; // ‘‘go’’
    }
    return 0;
} // end of main()

// Function to simulate sensing distance
int senseDistance() {
    // Return a random integer between 0 and 100
    return rand() % 101;
}

// Function to get distance values for each sensor
void getSensors(int sensors[]) {
    for (int i = 0; i < 4; i++) {
        sensors[i] = senseDistance();
    }
}

// Function to print out sensor values
void printSensors(int sensors[], string labels[]) 
{
    cout << "sensors = [";
    for (int i = 0; i < 4; i++) {
        cout << labels[i] << "=" << sensors[i];
        if (i < 3) {
            cout << "]["; // Separate entries with "][" except for the last one
        }
    }
    cout << "]\n";
}

// Function to find the direction that is furthest from an obstacle
int furthest(int sensors[])
{
	int maxindex=0; //initializing with the max index to find the furthest obstacle
	int max=0;
	for(int i=0; i<=3; i++)
	{
	if(sensors[i]>max) //checking in comparision with every element of the sensor to find the maximum
	{
		max=sensors[i]; //storing it in the maximum variable
		maxindex=i; //storing the corresponding maximum index in the defined variable
	}
	}
	return maxindex; 
	}
	


